--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Data for Name: blog_rank_run; Type: TABLE DATA; Schema: public; Owner: snac_admin
--

INSERT INTO blog_rank_run (blog_rank_run_id, start_time, end_time) VALUES (1, '2015-04-07 16:05:57.095327-04', '2015-04-07 16:05:57.095327-04');


--
-- Name: blog_rank_run_blog_rank_run_id_seq; Type: SEQUENCE SET; Schema: public; Owner: snac_admin
--

SELECT pg_catalog.setval('blog_rank_run_blog_rank_run_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

